
export interface SectionWrapperProps {
    paddingTop?: 'more' | 'normal' | 'less';
    paddingBottom?: 'more' | 'normal' | 'less';
}