// src/types/richtext.ts
export type RichTextContent = any; // Replace `any` with your Lexical AST or whatever structure you use
