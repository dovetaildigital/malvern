export interface Cf7CustomFormProps {
    formId: number | undefined;
    formIntro?: string;
    className?: string;
  }
  