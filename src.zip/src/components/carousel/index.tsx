// src/components/carousel/index.tsx
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { CarouselFields, CarouselContent } from '../../types/carousel';

interface CarouselProps {
  data: CarouselFields;
}

const Carousel: React.FC<CarouselProps> = ({ data }) => {
  // Destructure with default values and handle array fields
  const {
    carouselAutoplayBehaviour = ['never'],
    carouselShowNavigationArrows = true,
    carouselSpeed = 5000,
    carouselLoop = true,
    carouselPauseOnHover = true,
    carouselEffect = ['slide'],
    carouselPaginationDots = true,
    carouselSlidesPerView = 1,
    carouselSlidesToScroll = 1,
    carouselLazyLoad = false,
    carouselContents = [],
    carouselBreakpoints,
  } = data;


  
  // Get the first non-null value from array fields or use defaults
  const autoplayBehaviour = (carouselAutoplayBehaviour?.[0] as 'always' | 'never' | 'onScroll') || 'never';
  const effect = (carouselEffect?.[0] as 'slide' | 'fade') || 'slide';
  const slidesToShow = Math.max(1, carouselSlidesPerView || 1);
  const slidesToScroll = Math.max(1, carouselSlidesToScroll || 1);

  const totalSlides = carouselContents?.length || 0;
  const [current, setCurrent] = useState(0);
  const timer = useRef<NodeJS.Timeout | null>(null);

  const nextSlide = () => {
    if (!carouselContents) return;
    
    setCurrent(prev => {
      const next = prev + slidesToScroll;
      if (next >= totalSlides) {
        return carouselLoop ? next % totalSlides : prev;
      }
      return next;
    });
  };

  const prevSlide = () => {
    if (!carouselContents) return;
    
    setCurrent(prev => {
      const next = prev - slidesToScroll;
      if (next < 0) {
        return carouselLoop ? (totalSlides + next) % totalSlides : 0;
      }
      return next;
    });
  };

  useEffect(() => {
    if (autoplayBehaviour !== 'never' && carouselSpeed) {
      timer.current = setInterval(nextSlide, carouselSpeed);
      return () => { 
        if (timer.current) clearInterval(timer.current); 
      };
    }
  }, [autoplayBehaviour, carouselSpeed, current]);

  const handleMouseEnter = () => {
    if (carouselPauseOnHover && timer.current) {
      clearInterval(timer.current);
      timer.current = null;
    }
  };

  const handleMouseLeave = () => {
    if (autoplayBehaviour === 'always' && !timer.current) {
      timer.current = setInterval(nextSlide, carouselSpeed || 5000);
    }
  };

  if (!carouselContents || carouselContents.length === 0) return null;

  // Filter out any null items from the carousel contents
  const validContents = carouselContents.filter(
    (item): item is NonNullable<typeof item> => 
      item !== null && 
      item.carouselContentsImage?.node?.sourceUrl !== null
  );
// At the top of the Carousel component, after the props are destructured
console.log('Carousel data:', data);
console.log('Carousel contents:', carouselContents);
console.log('Valid contents:', validContents);
  if (validContents.length === 0) return null;

  return (
    <section className="p-12">
    <div 
      className="relative overflow-hidden w-full h-[600px]"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <AnimatePresence initial={false} custom={current}>
        {validContents.slice(current, current + slidesToShow).map((item, idx) => (
          <motion.div
            key={current + idx}
            className="absolute top-0 left-0 w-full h-full flex justify-center items-center"
            initial={{ x: effect === 'fade' ? 0 : '100%', opacity: effect === 'fade' ? 0 : 1 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: effect === 'fade' ? 0 : '-100%', opacity: effect === 'fade' ? 0 : 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="relative w-full h-full">
              {item.carouselContentsImage?.node?.sourceUrl && (
                <img
  src={item.carouselContentsImage.node.sourceUrl}
  alt={item.carouselContentsImage.node.altText || ''}
  className="w-full h-full object-cover"
  style={{ 
    width: '100%',
    height: '100%',
    objectFit: 'cover' 
  }}
  loading={carouselLazyLoad ? 'lazy' : 'eager'}
/>
              )}
              {item.carouselContentsCaption && (
                <div className="absolute bottom-0 left-0 w-full bg-black bg-opacity-50 p-2 text-white">
                  {item.carouselContentsCaption}
                </div>
              )}
              {item.carouselContentsLink?.url && (
                <a
                  href={item.carouselContentsLink.url}
                  target={item.carouselContentsLink.target || '_self'}
                  rel={item.carouselContentsLink.target === '_blank' ? 'noopener noreferrer' : ''}
                  className="absolute inset-0"
                  aria-label={item.carouselContentsLink.title || 'Carousel link'}
                />
              )}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {carouselShowNavigationArrows && validContents.length > 1 && (
        <>
          <button
            onClick={prevSlide}
            className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-50 p-2 rounded-full z-10 hover:bg-opacity-75 transition"
            aria-label="Previous slide"
          >
            ‹
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-50 p-2 rounded-full z-10 hover:bg-opacity-75 transition"
            aria-label="Next slide"
          >
            ›
          </button>
        </>
      )}

      {carouselPaginationDots && validContents.length > 1 && (
        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-2 z-10">
          {Array.from({ length: Math.ceil(validContents.length / slidesToShow) }).map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i * slidesToScroll)}
              className={`w-2 h-2 rounded-full transition-colors ${
                Math.floor(current / slidesToShow) === i ? 'bg-white' : 'bg-gray-500 bg-opacity-50'
              }`}
              aria-label={`Go to slide ${i + 1}`}
            />
          ))}
        </div>
      )}
    </div>
    </section>
  );
};

export default Carousel;